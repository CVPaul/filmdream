# FilmDream Studio

🎬 科幻电影创作辅助工具 - 从AI图片到视频制作的全流程管理平台

## 快速开始

### 安装依赖

```bash
# 安装所有依赖
npm run install:all

# 或分别安装
npm install
cd client && npm install
cd ../server && npm install
```

### 启动应用

```bash
# 同时启动前后端（推荐）
npm run dev

# 或分别启动
npm run dev:client   # 前端 http://localhost:3000
npm run dev:server   # 后端 http://localhost:3001
```

### 访问应用

打开浏览器访问: **http://localhost:3000**

## 功能模块

| 模块 | 说明 |
|------|------|
| 📸 图片库 | 管理AI生成的机甲/怪兽图片 |
| 👾 角色档案 | 创建角色详细资料和提示词模板 |
| 📖 故事编辑 | 编写剧本和故事大纲 |
| 🎭 场景规划 | 设计战斗场景和环境 |
| 🎬 分镜时间线 | 可视化编辑镜头序列 |
| 🎥 镜头构图 | 多层次构图规划（前中背景） |
| 🎓 技巧库 | 剪辑和拍摄技巧学习 |
| 🤖 ComfyUI导出 | 生成视频工作流 |

## 技术栈

- **前端**: React 18 + Vite + Tailwind CSS
- **后端**: Node.js + Express
- **数据库**: LowDB (本地JSON存储)

## 项目结构

```
filmdream-studio/
├── client/          # React前端
│   ├── src/
│   │   ├── components/  # 组件
│   │   ├── pages/       # 页面
│   │   ├── stores/      # 状态管理
│   │   └── data/        # 静态数据
│   └── package.json
├── server/          # Node.js后端
│   ├── routes/      # API路由
│   ├── data/        # 数据库文件
│   ├── uploads/     # 上传的图片
│   └── package.json
├── DESIGN.md        # 详细设计文档
└── package.json
```

## 开发进度

- [x] Phase 1: 项目初始化 + 基础框架
- [ ] Phase 2: 图片资产库完善
- [ ] Phase 3: 角色档案系统完善
- [ ] Phase 4: 故事编辑器完善
- [ ] Phase 5: 场景规划板完善
- [ ] Phase 6: 分镜时间线完善
- [ ] Phase 7: 镜头构图器完善
- [ ] Phase 8: ComfyUI集成
- [ ] Phase 9: 剪辑技巧库完善
- [ ] Phase 10: 打磨优化

## License

MIT
